package prob1C;

import com.sun.org.apache.xalan.internal.xsltc.util.IntegerArray;

import java.util.Arrays;
import java.util.stream.IntStream;

/**
 * Created by yafen on 2016/6/9.
 */
public class Main {
    public static void main(String[] args){
        IntStream intStream= IntStream.of(1,2,3,4,5,6,6);
        //intStream
    }
}
