package Q2;

public class Main {

	public static void main(String[] args) {
		BugReportGenerator brg = new BugReportGenerator();
		BugReportGenerator.reportGenerator();

	}
}
