package com.daxiang.org;

/**
 * Created by yafen on 2016/6/8.
 */
@FunctionalInterface
public interface MyFunctionalInterface {

    void test();
}
